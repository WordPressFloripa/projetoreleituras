# Projeto Releituras

Repositório do Projeto, o arquivo para a base de dados se encontra dentro de "_assets".

## Clone o projeto via SSH


bash
git clone git@github.com:WordPressFloripa/projetoreleituras.git